from microbit import *
import music

listanotas = ['g4:2', 'a', 'g', 'f', 'e', 'f', 'g:4',
              'f:4', 'e:2', 'f', 'g:4', 'g:2',
              'g', 'f', 'e', 'f', 'g:4', 'd:3',
              'g:3', 'e:3', 'c:3', 'r:4', 'g:2', 'a', 'g',
              'f', 'e', 'f', 'g:4', 'd:2', 'e', 'f:4',
              'e:2', 'f', 'g:4', 'g:2', 'a', 'g', 'f',
              'e', 'f', 'g:4', 'd:3', 'g:3', 'e:3', 'c:3', ]
music.play(listanotas)
