from microbit import *
import music


def ledON(posx, posy):
    display.set_pixel(posx, posy, 9)


def nivel225(minimo, maximo, lectura):
    ordenled = [[0, 4], [1, 4], [2, 4], [3, 4], [4, 4], 
                [0, 3], [1, 3], [2, 3], [3, 3], [4, 3],
                [0, 2], [1, 2], [2, 2], [3, 2], [4, 2],
                [0, 1], [1, 1], [2, 1], [3, 1], [4, 1],
                [0, 0], [1, 0], [2, 0], [3, 0], [4, 0]]
    cero = Image("00000:00000:00000:00000:00000")
    tope = Image("99999:99999:99999:99999:99999")
    nivel = int(225 * (lectura - minimo) / (maximo - minimo))
    if nivel <= 0:
        display.show(cero)
    elif nivel >= 225:
        display.show(tope)
    else:
        nleds9 = nivel // 9
        iultimo = nivel % 9
        if nleds9 > 0:
            for p in range(0, nleds9):
                posicion = ordenled[p]
                x = posicion[0]
                y = posicion[1]
                ledON(x, y)
            ultimo = ordenled[p + 1]
            display.set_pixel(ultimo[0], ultimo[1], iultimo)
        else:
            display.set_pixel(0, 4, iultimo)
t = 500
frecuencia = 440  # el nivel minimo
display.clear()
while frecuencia <= 1000:
    nivel225(440, 1000, frecuencia)
    music.pitch(frecuencia, t)
    frecuencia += 10
music.stop()
display.clear()
