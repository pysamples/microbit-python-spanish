from microbit import *
import music

t = 500
frecuencia = 440
while frecuencia <= 1000:
    display.scroll(str(frecuencia), delay=80)
    music.pitch(frecuencia, t)
    frecuencia += 20
music.stop()
