from microbit import *
for x in range(0, 5):
    for y in range(0, 5):
        if (x + y) % 2 == 0:  # si x + y es un número par
            valor = 9
        else:
            valor = 0
        display.set_pixel(x, y, valor)
    sleep(1000)
display.clear()
