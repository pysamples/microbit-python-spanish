from microbit import *
palabra = 'micro:bit'
lista = list(palabra)
lista2 = lista[6:]
for l in lista2:
	display.scroll(l)
	sleep(500)
display.scroll(str(len(lista2)))
