from microbit import *

if compass.is_calibrated() == False:
    compass.calibrate()
rumbo = compass.heading()

while True:
    degrees = compass.heading()
    if abs(rumbo - grados) > 5:
        rumbo = grados  # si se mueve, cambia rumbo
    elif button_a.is_pressed():
        compass.calibrate()# al pulsar A, se recalibra
        rumbo = grados
    elif button_b.is_pressed():  # al pulsar B,
        rumbo = grados  # cambia el rumbo
    else:
        if (rumbo > 338 or rumbo <= 23):
            r = "N"
        elif (rumbo > 23 and rumbo <= 68):
            r = "NE"
        elif (rumbo > 68 and rumbo <= 113):
            r = "E"
        elif (rumbo > 113 and rumbo <= 158):
            r = "SE"
        elif (rumbo > 158 and rumbo <= 203):
            r = "S"
        elif (rumbo > 203 and rumbo <= 248):
            r = "SO"
        elif (rumbo > 248 and rumbo <= 293):
            r = "O"
        else:
            r = "NO"
        r = r + " : " + str(rumbo)
        display.scroll(r)
    sleep(1000)
