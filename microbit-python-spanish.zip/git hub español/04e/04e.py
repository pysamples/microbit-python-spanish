from microbit import *
n = 1
signo = 1
while n <= 100:
    if signo > 0:
        display.show(Image.YES)
    else:
        display.show(Image.NO)
    sleep(500)
    n += 1
    signo *= -1
