from microbit import *
n = 1
signo = -1
borde = Image("99999:90009:90009:90009:99999")
interior = Image("00000:09990:09990:09990:00000")
while n <= 100:
    if signo > 0:
        display.show(borde)
    else:
        display.show(interior)
    sleep(500)
    signo *= -1
    n += 1
