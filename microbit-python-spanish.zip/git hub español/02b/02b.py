from microbit import *
i = 1
while i <= 100:
    display.scroll(str(i))
    i += 1
