import speech
from microbit import *

versos = ["KUHAHL", "GRIHTAHN", "EHSOHS", "MAHLDIHTOHS",
          "PEHROH", "MAHL", "RAHJOH", "MEH", "PAHRTAH",
          "SIH", "EHN", "KOHNKLUHJEHNDOH","LAH",
          "KAHRTAH", "NOH", "PAHGAHN", "KAHROHS",
          "SUHS", "GRIHTOHS"]
for palabra in versos:
    speech.pronounce(palabra)
    sleep(200)
