import speech
from microbit import *

numeros = ["UHNOH", "DOHS", "TREHS", "KUHAHTROH", "THIHNKOH", "SEHIHS",
           "SIHEHTEH", "OHCHOH", "NUHEHBEH", "DIHEHTH"]
for n in range(0, len(numeros)):
    speech.pronounce(numeros[n])
    display.scroll(str(n + 1), delay=80)
    sleep(500)
