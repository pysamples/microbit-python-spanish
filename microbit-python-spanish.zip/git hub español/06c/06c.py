from microbit import *
import speech

frase = "A bird in the hand is worth two in the bush"
palabras = frase.split()
display.scroll(frase, delay=50, wait=False)
for palabra in palabras:
    speech.say(palabra, speed=120, pitch=100,
               throat=100, mouth=200)
    sleep(700)
