'''
lee datos del serial
añade la fecha y hora a que se recibe cada dato
archiva todos los datos en un archivo csv
'''

import serial
import csv
import datetime


port = "/dev/ttyACM0"
baud = 115200
s = serial.Serial(port)
s.baudrate = baud
t0 = datetime.datetime.now()
str_t0 = t0.strftime("%Y-%m-%d %H:%M:%S")

while True:
    voltajerecibido = s.readline()
    milivoltios = float(voltajerecibido) * 3300.0 / 1024
    calibracion = 45
    centigrados = round(((milivoltios - 500) / 10) + calibracion, 1)
    t = datetime.datetime.now()
    str_t = t.strftime("%Y-%m-%d %H:%M:%S")
    print(str_t + '   ' + str(centigrados))
    with open('temperaturas.csv', 'a') as csvfile:
        fieldnames = ['fecha_hora', 'temperatura']
        writer_header = csv.writer(csvfile)  # esta linea y la siguiente
        writer_header.writerow(fieldnames)   # añaden los headers
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        # writer.writeheader()
        writer.writerow({'fecha_hora': str_t, 'temperatura': centigrados})
