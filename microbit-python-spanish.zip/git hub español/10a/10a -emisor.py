from microbit import *
import radio

radio.on()
radio.config(channel=68)
radio.config(power=7)
tiempoespera = 30  # segundos entre mediciones = una cada 30 s = 2880 al día
# micro:bit emisora, conectada al sensor de temperatura
while True:
    voltaje = pin0.read_analog()
    radio.on()
    radio.send(str(voltaje))
    sleep(tiempoespera * 1000)
    radio.off()
    display.scroll(str(voltaje), delay=80)
