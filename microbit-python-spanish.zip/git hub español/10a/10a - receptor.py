from microbit import *
import radio

radio.on()
radio.config(channel=68)
radio.config(power=7)
# receptor, recibe valor de voltaje y lo envia a puerto serie
while True:
    recibido = radio.receive()
    if recibido is not None:
        print(recibido)  # envía la medición de temperatura
        sleep(1)
        display.scroll(recibido)  # muestra la temperatura en los led
    else:
        display.show(Image.SMILE)
