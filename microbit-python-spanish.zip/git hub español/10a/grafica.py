import pandas as pd
import numpy as np
from matplotlib import pylab as plt
import matplotlib.dates as mdates


data = pd.read_csv('temperaturas2.csv',  parse_dates=['fecha'])
data.set_index('fecha', inplace=True)
#plot data
fig, ax = plt.subplots(figsize=(12, 9))
data.plot(ax=ax, linewidth=3, color="blue")
major_ticks = np.arange(-5, 40, 5)
ax.set_yticks(major_ticks)
ax.axes.set_ylim(-10, 40)
ax.xaxis.set_major_locator(mdates.HourLocator())
ax.xaxis.set_major_formatter(mdates.DateFormatter('%H'))
ax.grid()
fig.savefig("grafica.png", format='png', dpi=300)
