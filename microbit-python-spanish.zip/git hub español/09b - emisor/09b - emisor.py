from microbit import *
import radio

radio.on()
radio.config(channel=68)
radio.config(power=7)

while True:
    x = accelerometer.get_x()
    if x > 100:
        imagen = "00099:00099:00099:00099:00099"
    elif x < -100:
        imagen = "99000:99000:99000:99000:99000"
    else:
        imagen = "00000:00000:00900:00000:00000"
    radio.send(imagen)
    sleep(10)  # error data packet is not a string
    display.show(Image(imagen))
