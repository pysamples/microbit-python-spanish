from microbit import *
alterna = 1
while True:
    if alterna > 0:
        fuera = 9
        dentro = 0
    else:
        fuera = 0
        dentro = 9
    for x in range(0, 5):
        for y in range(0, 5):
            if x == 0 or y == 0:
                valor = fuera
            elif x == 4 or y == 4:
                valor = fuera
            else:
                valor = dentro
            display.set_pixel(x, y, valor)
    sleep(1000)
    alterna *= -1
