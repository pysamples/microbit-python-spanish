from microbit import *
nombres = ["Diego", "Paula", "Miguel", "Sara"]
for n in nombres:
	display.scroll(n)
	sleep(500)
