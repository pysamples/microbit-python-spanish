from microbit import *
import radio

radio.on()
radio.config(channel=68)
radio.config(power=7)

while True:
    recibido = radio.receive()
    if recibido is not None:
        display.show(Image(recibido))
    else:
        display.clear()
