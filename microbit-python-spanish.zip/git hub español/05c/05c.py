from microbit import *
flechas = [Image.ARROW_N, Image.ARROW_NE, Image.ARROW_E, Image.ARROW_SE,
           Image.ARROW_S, Image.ARROW_SW, Image.ARROW_W, Image.ARROW_NW]
i = 0
while i < len(flechas):
    display.scroll(str(i + 1))
    display.show(flechas[i])
    i += 1
    sleep(500)
