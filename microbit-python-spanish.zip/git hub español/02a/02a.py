from microbit import *
for i in range(1, 101):
    display.scroll(str(i))
