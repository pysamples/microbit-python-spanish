from microbit import *
import radio

radio.on()
radio.config(channel=68)
radio.config(power=7)
uno = "00009:00099:00909:00009:90009"
dos = "00999:00009:00999:40900:90999"
tres = "00999:00009:00999:90009:90999"
cuatro = "00909:00909:40999:90009:90009"
cinco = "00999:00900:90999:90009:90999"
seis = "00900:40900:90999:90909:90999"
siete = "00999:90009:90009:90009:90009"
ocho = "40999:90909:90999:90909:90999"
nueve = "90999:90909:90999:90009:90009"
cero = "00999:00909:00909:00909:00999"
imagenes = [cero, uno, dos, tres, cuatro, cinco, seis, siete, ocho, nueve]
cambio = 0
nivel = 0
display.scroll("Esperando", delay=100)
sleep(500)
display.show(Image.SMILE)
while True:
    if button_a.was_pressed() and button_b.was_pressed():
        radio.send("99999:90909:90009:90009:99999")
        sleep(500)
        radio.off()  # apaga la radio del emisor
    elif button_b.was_pressed():
        cambio = 1
    elif button_a.was_pressed():
        cambio = -1
    else:
        cambio = 0
    nivel += cambio
    if nivel < 0:
        nivel = 9
    elif nivel > 9:
        nivel = 0
    if cambio != 0:
        radio.send(imagenes[nivel])
        sleep(10)  # no error data packet is not a string
        display.show(Image(imagenes[nivel]))
    recibido = radio.receive()
    if recibido is not None:
        display.show(Image(recibido))
        sleep(1000)
        if recibido == "99999:90909:90009:90009:99999":
            radio.off()  # apaga la radio del receptor
