from microbit import *
# asignamos un pin a cada color del LED
rojo = pin0
azul = pin1
verde = pin2
t = 1000
while True:
    if button_a.is_pressed() and button_b.is_pressed():
        display.scroll("off", delay=80)
        azul.write_digital(0)
        break
    elif button_a.is_pressed():
        azul.write_digital(0)
        rojo.write_digital(1)
        sleep(t)
        rojo.write_digital(0)
    elif button_b.is_pressed():
        azul.write_digital(0)
        verde.write_digital(1)
        sleep(t)
        verde.write_digital(0)
    else:
        azul.write_digital(1)
