from microbit import *
display.scroll('Hola!', wait=False, loop=True)
