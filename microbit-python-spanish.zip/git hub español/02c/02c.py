from microbit import *
for i in range(10, -1, -1):
    display.scroll(str(i))
