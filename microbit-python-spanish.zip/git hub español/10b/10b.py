n = 100
diccionario = {1: 1, 2: 1}
i = 3
while i <= n:
    diccionario[i] = diccionario[i - 1] + diccionario[i - 2]
    i += 1
with open('diccionario.txt', 'w') as archivotxt:
    archivotxt.write(str(diccionario))
