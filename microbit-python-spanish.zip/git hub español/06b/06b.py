from microbit import *
import music

melodias = [music.DADADADUM, music.ENTERTAINER, music.PRELUDE, music.ODE, 
            music.NYAN, music.RINGTONE, music.FUNK, music.BLUES, music.BIRTHDAY,
            music.WEDDING, music.FUNERAL, music.PUNCHLINE, music.PYTHON,
            music.BADDY, music.CHASE, music.BA_DING, music.WAWAWAWAA,
            music.JUMP_UP, music.JUMP_DOWN, music.POWER_UP, music.POWER_DOWN]
i = 0
l = len(melodias)

while True:
    if button_a.is_pressed() and button_b.is_pressed():
        display.scroll("AB")
        display.scroll("adios!", delay=80)
        break
    elif button_a.is_pressed():
        if i in range(0, l - 1):
            i += 1
        else:
            i = 0
    elif button_b.is_pressed():
        if i in range(0, l - 1):
            i -= 1
        else:
            i = 0
    display.scroll(str(i), delay=80)
    music.play(melodias[i])
    sleep(2000)
