from microbit import *
imagenes = [Image.HEART, Image.HEART_SMALL, Image.HAPPY, Image.SMILE,
            Image.SAD, Image.CONFUSED, Image.ANGRY, Image.ASLEEP,
            Image.SURPRISED, Image.SILLY, Image.FABULOUS, Image.MEH,
            Image.YES, Image.NO, Image.TRIANGLE, Image. TRIANGLE_LEFT,
            Image.CHESSBOARD, Image.DIAMOND, Image.DIAMOND_SMALL,
            Image.SQUARE, Image.SQUARE_SMALL, Image.RABBIT,  Image.COW,
            Image.MUSIC_CROTCHET, Image.MUSIC_QUAVER, Image.MUSIC_QUAVERS,
            Image.PITCHFORK, Image.XMAS, Image.PACMAN, Image.TARGET,
            Image.TSHIRT, Image.ROLLERSKATE, Image.DUCK, Image.HOUSE,
            Image.TORTOISE, Image.BUTTERFLY, Image.STICKFIGURE,
            Image.GHOST, Image.SWORD, Image.GIRAFFE, Image.SKULL,
            Image.UMBRELLA, Image.SNAKE]
for i in imagenes:
	display.show(i)
    	sleep(500)
