from microbit import *
figura = Image("56789:"
               "45678:"
               "34567:"
               "23456:"
               "12345")
display.show(figura)
