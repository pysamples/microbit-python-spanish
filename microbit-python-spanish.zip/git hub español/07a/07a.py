from microbit import *
import music


def nivel(minimo, maximo, lectura):
    n0 = Image("00000:00000:00000:00000:00000")
    n1 = Image("00000:00000:00000:00000:55555")
    n2 = Image("00000:00000:00000:00000:99999")
    n3 = Image("00000:00000:00000:55555:99999")
    n4 = Image("00000:00000:00000:99999:99999")
    n5 = Image("00000:00000:55555:99999:99999")
    n6 = Image("00000:00000:99999:99999:99999")
    n7 = Image("00000:55555:99999:99999:99999")
    n8 = Image("00000:99999:99999:99999:99999")
    n9 = Image("55555:99999:99999:99999:99999")
    n10 = Image("99999:99999:99999:99999:99999")
    niveles = [n0, n1, n2, n3, n4, n5,
               n6, n7, n8, n9, n10]
    decil = int(10 * (lectura - minimo) / (maximo - minimo))
    if decil < 0:
        decil = 0
    elif decil > 10:
        decil = 10
    imagen = niveles[decil]
    display.show(imagen)
t = 500
frecuencia = 440  # el nivel minimo
display.show(Image("00000:00000:00000:00000:00000"))
while frecuencia <= 1000:
    nivel(440, 1000, frecuencia)
    music.pitch(frecuencia, t)
    frecuencia += 20
    music.stop()
    nivel(440, 1000, 0)
