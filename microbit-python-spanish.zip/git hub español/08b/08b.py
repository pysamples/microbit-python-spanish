from microbit import *

def Abaco(num):
    strnumero = str(num)
    lnumero = list(strnumero)
    l = len(lnumero)
    u = lnumero[l - 1]  # unidades
    if l > 1:
        d = lnumero[l - 2]  # decenas
        if l > 2:
            c = lnumero[l - 3]  # centenas
            if l > 3:
                m = lnumero[l - 4]  # unidades de millar
                if l > 4:
                    dm = lnumero[l - 5]  # decenas millar
                else:  # si es menor de 10000
                    dm = 0
            else:  # si es menor de 1000
                m = 0
                dm = 0
        else:  # si es menor de 100
            c = 0
            m = 0
            dm = 0
    else:  # si es menor de 10
        d = 0
        c = 0
        m = 0
        dm = 0
    # valores posibles de una columna
    c0 = "00000"  # 0
    c1 = "05000"  # 1
    c2 = "05500"  # 2
    c3 = "05550"  # 3
    c4 = "05555"  # 4
    c5 = "90000"  # 5
    c6 = "95000"  # 6
    c7 = "95500"  # 7
    c8 = "95550"  # 8
    c9 = "95555"  # 9
    cifras = [c0, c1, c2, c3, c4, c5, c6, c7, c8, c9]
    unidades = cifras[int(u)]
    decenas = cifras[int(d)]
    centenas = cifras[int(c)]
    millares = cifras[int(m)]
    decmillar = cifras[int(dm)]
    rows = [0, 0, 0, 0, 0]
    im = ""
    for j in range(0, 5):
        rows[j] = str(decmillar[j] + millares[j] +
                      centenas[j] + decenas[j] + unidades[j])
        im += rows[j] + ":"
    imageAbaco = im[0:-1]
    return(imageAbaco)

campo = compass.get_field_strength()
display.scroll("Pulsa A o B")
imagen = Image.SQUARE
display.show(imagen, delay=1000)
while True:
    if button_a.was_pressed():
        t = temperature()
        imagen = Image(Abaco(t))
    elif button_b.was_pressed():
        b = compass.get_field_strength()
        if (100 * int(abs(campo - b) / campo)) > 1:
            # si el campo varía en mas del 1%
            campo = b
            # campo en nT, mostrará en microT
        mT = int(campo / 1000)
        imagen = Image(Abaco(mT))      
    display.show(imagen, delay=1000)
    sleep(1000)
